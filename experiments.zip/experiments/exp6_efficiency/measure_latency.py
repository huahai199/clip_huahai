"""
表6 检索效率测量: 测量图像编码、文本编码及整体推理延迟
"""
import sys; sys.path.insert(0, "../../")
import os, time
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import torch
import torch.nn.functional as F
from model_v2 import QwenCLIPRetriever

# ── 配置 ──
USE_SOFT_PROMPT        = True
NUM_PROMPT_TOKENS      = 16
USE_MULTISCALE         = True
NUM_MULTISCALE_LAYERS  = 4
CLIP_USE_LORA          = True
CLIP_LORA_R            = 4
WARMUP_ITERS           = 30
MEASURE_ITERS          = 100
BATCH_SIZE             = 1
DEVICE                 = "cuda"


def measure_latency():
    print("=" * 55)
    print("  检索效率测量")
    print(f"  Batch Size: {BATCH_SIZE}")
    print(f"  Warmup: {WARMUP_ITERS}, Measure: {MEASURE_ITERS}")
    print("=" * 55)

    # 加载模型
    model = QwenCLIPRetriever(
        qwen_name="Qwen/Qwen2.5-1.5B",
        clip_name="OFA-Sys/chinese-clip-vit-base-patch16",
        dropout=0.0,
        use_lora=False,
        clip_use_lora=CLIP_USE_LORA,
        clip_lora_r=CLIP_LORA_R,
        use_soft_prompt=USE_SOFT_PROMPT,
        num_prompt_tokens=NUM_PROMPT_TOKENS,
        use_multiscale=USE_MULTISCALE,
        num_multiscale_layers=NUM_MULTISCALE_LAYERS,
    )
    model.text_encoder.qwen.requires_grad_(False)
    model = model.to(DEVICE)
    model.eval()

    # 构造模拟输入
    dummy_image = torch.randn(BATCH_SIZE, 3, 224, 224).to(DEVICE)
    dummy_text  = ["发动机气缸盖拆装步骤说明，需先松开紧固螺栓并按图示顺序拆除各部件"] * BATCH_SIZE

    # ── Warmup ──
    print("[INFO] Warming up...")
    for _ in range(WARMUP_ITERS):
        with torch.no_grad():
            _ = model(images=dummy_image)
            _ = model(texts=dummy_text)

    # ── 测量图像编码 ──
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(MEASURE_ITERS):
        with torch.no_grad():
            _ = model(images=dummy_image)
    torch.cuda.synchronize()
    img_time = (time.perf_counter() - t0) / MEASURE_ITERS * 1000

    # ── 测量文本编码 ──
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(MEASURE_ITERS):
        with torch.no_grad():
            _ = model(texts=dummy_text)
    torch.cuda.synchronize()
    txt_time = (time.perf_counter() - t0) / MEASURE_ITERS * 1000

    total_time = img_time + txt_time

    print(f"\n{'='*45}")
    print(f"  图像编码延迟:  {img_time:.2f} ms")
    print(f"  文本编码延迟:  {txt_time:.2f} ms")
    print(f"  端到端总延迟:  {total_time:.2f} ms")
    print(f"{'='*45}")

    # 同时测量 Chinese-CLIP 基线
    print("\n[INFO] 对比: Chinese-CLIP 零样本推理延迟...")
    from transformers import ChineseCLIPVisionModel, ChineseCLIPTextModel, AutoTokenizer
    clip_name = "OFA-Sys/chinese-clip-vit-base-patch16"
    img_model = ChineseCLIPVisionModel.from_pretrained(clip_name).to(DEVICE).eval()
    txt_model = ChineseCLIPTextModel.from_pretrained(clip_name).to(DEVICE).eval()
    tokenizer = AutoTokenizer.from_pretrained(clip_name)

    # Warmup CLIP
    for _ in range(WARMUP_ITERS):
        with torch.no_grad():
            _ = img_model(pixel_values=dummy_image)
            inputs = tokenizer(dummy_text, return_tensors="pt", padding=True,
                              truncation=True, max_length=52).to(DEVICE)
            _ = txt_model(**inputs)

    # Measure CLIP image
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(MEASURE_ITERS):
        with torch.no_grad():
            _ = img_model(pixel_values=dummy_image)
    torch.cuda.synchronize()
    clip_img = (time.perf_counter() - t0) / MEASURE_ITERS * 1000

    # Measure CLIP text
    inputs = tokenizer(dummy_text, return_tensors="pt", padding=True,
                      truncation=True, max_length=52).to(DEVICE)
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(MEASURE_ITERS):
        with torch.no_grad():
            _ = txt_model(**inputs)
    torch.cuda.synchronize()
    clip_txt = (time.perf_counter() - t0) / MEASURE_ITERS * 1000

    print(f"  Chinese-CLIP 图像: {clip_img:.2f} ms")
    print(f"  Chinese-CLIP 文本: {clip_txt:.2f} ms")
    print(f"  Chinese-CLIP 总计: {clip_img + clip_txt:.2f} ms")

    # 模型参数量统计
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\n[INFO] 模型参数: {total/1e6:.1f}M, 可训练: {trainable/1e6:.2f}M")


if __name__ == "__main__":
    measure_latency()
